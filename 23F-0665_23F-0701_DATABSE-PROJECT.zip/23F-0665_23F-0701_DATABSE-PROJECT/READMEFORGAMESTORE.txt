Restore the database on your machine:

-open SSMS, right-click Databases → Restore Database.
-select Device, browse to the .bak file you got, and restore it.

Install the application on your machine:

-click on .exe file in Application Files Folder